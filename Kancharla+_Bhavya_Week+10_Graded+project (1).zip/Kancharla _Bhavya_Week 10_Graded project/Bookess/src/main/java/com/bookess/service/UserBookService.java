package com.bookess.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookess.model.Book;
import com.bookess.model.User;
import com.bookess.model.UserBook;
import com.bookess.repository.BookRepo;
import com.bookess.repository.UserBookRepo;
import com.bookess.repository.UserRepo;
import com.bookess.verify.LoginUser;
import com.bookess.verify.LikeOrLater;

@Service
public class UserBookService {
	

	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private BookRepo bookRepo;
	
	@Autowired
	private UserBookRepo userBookRepo;
	
	

	public List<Book> getBooks() {
		return bookRepo.findAll();
	}

	public List<UserBook> getBooksByUserAndReadLater(String email) throws Exception {
		User userName = UserService.map.get(email);
		if (userName == null) {
			throw new Exception("User Not Login");
		} 
		return userBookRepo.findByUserEmailAndReadLater(email, true);
	}
	
	public List<UserBook> getBooksByUserAndLiked(String email) throws Exception {
		User userName = UserService.map.get(email);
		if (userName == null) {
			throw new Exception("User Not Login");
		} 
		return userBookRepo.findByUserEmailAndLiked(email, true);
	}

	public String readLater(LikeOrLater vo) {
		String email = vo.getEmail();
		User userName = UserService.map.get(email);
		if (userName == null) {
			return "please login first";
		} 
		else {
			UserBook findByUserIdAndBookId = userBookRepo.findByUserEmailAndBookId(email,vo.getBookId());
			if(findByUserIdAndBookId!=null) {
				findByUserIdAndBookId.setReadLater(true);
				userBookRepo.save(findByUserIdAndBookId);
				return "Success";
			}else {
				Optional<User> user = userRepo.findByEmail(email);
				Optional<Book> book = bookRepo.findById(vo.getBookId());
				
				if(user.isPresent() && book.isPresent()) {
					UserBook userBook=new UserBook();
					userBook.setBook(book.get());
					userBook.setUser(user.get());
					userBook.setReadLater(true);
					userBookRepo.save(userBook);
					return "Success";
				}
				return "Failed";
			}
			
		}
	}

	public String liked(LikeOrLater vo) {
		String email = vo.getEmail();
		User userName = UserService.map.get(email);
		if (userName == null) {
			return "please login first";
		} 
		else {
			UserBook findByUserIdAndBookId = userBookRepo.findByUserEmailAndBookId(email,vo.getBookId());
			if(findByUserIdAndBookId!=null) {
				findByUserIdAndBookId.setLiked(true);
				userBookRepo.save(findByUserIdAndBookId);
				return "Success";
			}else {
				Optional<User> user = userRepo.findByEmail(email);
				Optional<Book> book = bookRepo.findById(vo.getBookId());
				
				if(user.isPresent() && book.isPresent()) {
					UserBook userBook=new UserBook();
					userBook.setBook(book.get());
					userBook.setUser(user.get());
					userBook.setLiked(true);
					userBookRepo.save(userBook);
					return "Success";
					
				}
				return "Failed";
			}
		}
	}

}
