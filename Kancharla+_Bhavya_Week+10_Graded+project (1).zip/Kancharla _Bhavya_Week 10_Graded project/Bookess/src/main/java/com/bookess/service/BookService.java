package com.bookess.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookess.model.Admin;
import com.bookess.model.Book;
import com.bookess.model.User;
import com.bookess.model.UserBook;
import com.bookess.repository.BookRepo;
import com.bookess.repository.UserBookRepo;
import com.bookess.repository.UserRepo;

@Service
public class BookService {

	@Autowired
	private BookRepo bookRepository;

	@Autowired
	private UserBookRepo userBookRepo;

	
	public String createBook(Book book, String email) {
		Admin admin = AdminService.map.get(email);
		if (admin == null) {
			return "To Add book, please login as admin first";
		} else if (!admin.getRole().equalsIgnoreCase("admin")) {
			return "Only Admin can add a book";
		} else {
			Book save = bookRepository.save(book);
			if (save != null) {
				return "Success";
			}
		}
		return "Failed";

	}

	public String updateBook(Book book, String email) {
		Admin admin = AdminService.map.get(email);
		if (admin == null) {
			return "To Add book, please login as admin first";
		} else if (!admin.getRole().equalsIgnoreCase("admin")) {
			return "Only Admin can add a book";
		} else {
			Optional<Book> findById = bookRepository.findById(book.getId());
			if (findById.empty() != null) {
				return "Book Not Exit in Database with bookId " + book.getId();
			}else {
				Book save = bookRepository.save(book);
				return "Book updated successfully";
			}
		}
		
	}

	public Book getBookById(Long bookId) {
		Optional<Book> findById = bookRepository.findById(bookId);
		if (findById.isPresent()) {
			return findById.get();
		}
		return null;
	}

	public String deleteBook(Long bookId, String email) {
		Admin admin = AdminService.map.get(email);
		if (admin == null) {
			return "To Add book, please login as admin first";
		} else if (!admin.getRole().equalsIgnoreCase("admin")) {
			return "Only Admin can add a book";
		}else {
			List<UserBook> findByBookId = userBookRepo.findByBookId(bookId);
			userBookRepo.deleteAll(findByBookId);
			bookRepository.deleteById(bookId);
			return "success";			
		}
	}

}
