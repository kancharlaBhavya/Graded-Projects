package com.bookess.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookess.model.Admin;
import com.bookess.service.AdminService;
import com.bookess.verify.LoginAdmin;


	@RestController
	@RequestMapping("/admin")
	public class AdminController {
		public AdminController(){
			
		}

		@Autowired
		private AdminService adminService;
		private Object adminEmail;
		
		@PostMapping("/login")
		public String login(@RequestBody LoginAdmin loginVo) {
			return adminService.login(loginVo);
		}
		
		
		@GetMapping("/logout")
		public String logout(@RequestParam(value = "email") String email) {
			return adminService.logout(email);
		}
		
		@CrossOrigin(exposedHeaders="Access-Control-Allow-Origin")
		@PostMapping(value="/createAdmin")
		public String createAdmin(@RequestBody Admin admin) {
			return adminService.createAdmin(admin);
		}
		
		@PutMapping(value="/updateAdmin")
		public String updateAdmin(@RequestBody Admin admin) {
			return adminService.updateAdmin(admin);
		}
		
		@GetMapping(value="/getAdminById")
		public Admin getAdminById(@RequestParam(value = "adminId") Long adminId) {
			return adminService.getAdminById(adminId);
		}
		
		@DeleteMapping
		public String deleteAdmin(@RequestParam("adminEmail")String adminEmail) {
			return adminService.deleteAdmin(adminEmail);
		}


}
