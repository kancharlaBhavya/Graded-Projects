package com.bookess.service;

import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookess.model.Admin;
import com.bookess.repository.AdminRepo;
import com.bookess.verify.LoginAdmin;



	@Service
	public class AdminService {
		public AdminService() {
			
		}
		public static HashMap<String, Admin> map = new HashMap<>();

		@Autowired
		private AdminRepo adminRepository;
		public String createAdmin(Admin admin) {
		    String role = admin.getRole();
			if (role != null && (role.equalsIgnoreCase("admin") || role.equalsIgnoreCase("user"))) {
				Optional<Admin> findByEmail = adminRepository.findByEmail(admin.getEmail());
				if (findByEmail.empty() != null) {
					Admin save = adminRepository.save(admin);
					return "Success";
				} else {
					return "Email already exists";

				}
			} else {
				return "Failed, Role mismatch";
			}

		}

		public String login(LoginAdmin loginVo) {

			String email = loginVo.getEmail();

			Optional<Admin> findByEmail = adminRepository.findByEmail(email);
			if (findByEmail.isPresent()) {
				Admin adminEntity = findByEmail.get();
				String password = adminEntity.getPassword();
				if (loginVo.getPassword().equals(password)) {
					if (map.get(email) == null) {
						map.put(email, adminEntity);
						return "Login SuccessFull";
					} else {
						return "Already logged in";
					}
				}
			}
			return "Login Failed";
		}

		public String logout(String email) {

			if (map.get(email) != null) {
				map.remove(email);
				return "Logout Success";
			} else {
				return "Please Login First";
			}

		}

	    public String updateAdmin(Admin admin) {
			Optional<Admin> findById = adminRepository.findById(admin.getId());
			if (findById.empty() != null) {
				return "User Not Exit in Database with userId " + admin.getId();
			}
			Admin save = adminRepository.save(admin);
			return "Success";
		}

		public Admin getAdminById(Long adminId) {
			Optional<Admin> findById = adminRepository.findById(adminId);
			if (findById.isPresent()) {
				return findById.get();
			}
			return null;
		}

		public String deleteAdmin(String adminEmail) {
			
			Optional<Admin> admin= adminRepository.findByEmail(adminEmail);
			if (admin == null) {
				return "please login  first";
			} else {
				return "Admin is deleted ";
			}
		}


}



