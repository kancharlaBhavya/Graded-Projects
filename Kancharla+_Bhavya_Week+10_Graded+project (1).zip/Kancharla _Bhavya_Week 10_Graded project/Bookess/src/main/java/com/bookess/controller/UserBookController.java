package com.bookess.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookess.model.Book;
import com.bookess.model.UserBook;
import com.bookess.service.UserBookService;
import com.bookess.verify.LoginUser;
import com.bookess.verify.LikeOrLater;

@RestController
@RequestMapping("/userbook")
public class UserBookController {
	public UserBookController() {
		
	}
	
	
	@Autowired
	private UserBookService userBookService;
	
	@GetMapping("/getBooks")
	public List<Book> getBooks(){
		return userBookService.getBooks();
	}
	
	@GetMapping("/getBooksByUserAndReadLater")
	public List<UserBook> getBooksByUserAndReadLater(@RequestParam("email") String email) throws Exception{
		return userBookService.getBooksByUserAndReadLater(email);
	}
	
	@GetMapping("/getBooksByUserAndLiked")
	public List<UserBook> getBooksByUserAndLiked(@RequestParam("email") String email) throws Exception{
		return userBookService.getBooksByUserAndLiked(email);
	}
	
	
	@PostMapping("/readLater")
	public String readLater(@RequestBody LikeOrLater vo) {
		return userBookService.readLater(vo);
	}
	@PostMapping("/liked")
	public String liked(@RequestBody LikeOrLater vo) {
		return userBookService.liked(vo);
	}
	
		
	
	

}
