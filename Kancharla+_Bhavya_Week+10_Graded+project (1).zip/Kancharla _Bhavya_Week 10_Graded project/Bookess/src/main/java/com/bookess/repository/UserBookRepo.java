package com.bookess.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bookess.model.UserBook;

@Repository
public interface UserBookRepo extends JpaRepository<UserBook, Long>{

	
	List<UserBook> findByUserEmailAndReadLater(String email,boolean readLater);
	
	List<UserBook> findByUserEmailAndLiked(String email,boolean liked);

	UserBook findByUserEmailAndBookId(String email, Long userId2);
	
	List<UserBook> findByUserEmail(String email);
	
	List<UserBook> findByBookId(Long bookId);
	
	
	
}
