show databases;
create database springboot; 
use springboot;

show tables;

insert into users values(2,"abc@gmail.com", "abc", "abc123", "admin");
insert into users values(3, "xyz@gmail.com", "xyz", "xyz123", "user");


insert into books values(2, "Author 20", "Book 20", "20th book");
insert into books values(3, "Author 21", "Book 21", "21th book");

select *from users;
select *from books;
select *from user_book;